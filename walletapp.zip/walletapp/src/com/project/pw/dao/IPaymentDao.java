package com.project.pw.dao;

import com.project.pw.bean.PaymentBean;

public interface IPaymentDao {
	
	int accountCreation(PaymentBean a);
	
	PaymentBean loginUser(int accNo);
	
	void updateDetails(int accNo, PaymentBean a);

}
