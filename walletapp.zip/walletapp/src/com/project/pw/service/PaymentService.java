package com.project.pw.service;

import com.project.pw.bean.PaymentBean;
import com.project.pw.dao.IPaymentDao;
import com.project.pw.dao.PaymentDao;

public class PaymentService implements IPaymentService {
	PaymentBean temp = new PaymentBean();
	IPaymentDao dao;
	 public PaymentService() {
		 dao = new PaymentDao();
		 
	}
	 
	 static String namePatt = "[A-Z]{1}[a-z]{2,}";                    
	 static String numPatt = "[0-9]{10}";                                   
	 static String passPatt = "[A-Z]{1}[a-z]{2,6}(\\d){1,4}(\\W){1}";      
	
	 
	@Override
	public int addAcc(PaymentBean a) {
		
		return dao.accountCreation(a);
	}

	
	
	//deposit
	@Override
	public double deposit(double money) {
		temp.setCustBal(temp.getCustBal()+money);
		dao.updateDetails(temp.getAccNum(),temp);
		return temp.getCustBal();
	}

	//withdraw
	@Override
	public double withdraw(double money) {
		if(money<temp.getCustBal()) {
		temp.setCustBal(temp.getCustBal()-money);
		dao.updateDetails(temp.getAccNum(),temp);
		}
		else
			System.out.println("Low Balance");
		return temp.getCustBal();
	}

	
	//show balance
	@Override
	public double showBalance() {
		
		return temp.getCustBal();
	}
	
	//Name validation
public  boolean validateCustName(String name)
{	if(name.matches(namePatt))
		return true;
	else
		return false;
	
}


//Phone number validation
public  boolean validateCustPhoneNumber(String number) {
	if(number.matches(numPatt))
		return true;
	else
		return false;
}

//Age validation
public boolean validateCustAge(int age) {
	if(age<=110&&age>=1)
		return true;
	else
		return false;
	
}


//Password validation
public  boolean validateCustPwd(String pwd) {
	if(pwd.matches(passPatt))
		return true;
	else
		return false;
}

//Amount validation
public  boolean validateAmt(double amt) {
if(amt>0.00)
	return true;
else
	return false;
}


//UserName validation
@Override
public boolean checkLogin(int accNo) {
	temp =dao.loginUser(accNo);
	if(temp!=null)
	return true;
	else 
		return false;
}


//Password match validation
@Override
public boolean checkPassword(String pwd) {
	
	if(temp.getCustPwd().matches(pwd))
		return true;
	else
		return false;

	
}


@Override
public String currentUser() {
	
	return temp.getCustName();
}

@Override
public boolean transferAmt(int toAccNo, double money) {
	PaymentBean ftTemp =new PaymentBean();
	if(temp.getCustBal()>=money) {
	ftTemp = dao.loginUser(toAccNo);
	if(ftTemp!=null)
	{
		double tamt=ftTemp.getCustBal()+money;
	
		ftTemp.setCustBal(tamt);
		double cbal =temp.getCustBal()-money;
		
		temp.setCustBal(cbal);
		dao.updateDetails(temp.getAccNum(), temp);
		dao.updateDetails(ftTemp.getAccNum(), ftTemp);
		return true;
	}
	
	
}
	else if(temp.getCustBal()<money)
	{
		System.out.println("Low Balance");
	}
	
	else
		System.out.println("No such account");
	return false;
}
}
