package com.project.pw.service;

import com.project.pw.bean.PaymentBean;

public interface IPaymentService {

	int addAcc(PaymentBean a);
	double deposit(double money);
	double withdraw(double money) ;
	double showBalance();
	boolean checkLogin(int accNo);                     //returns either true/false
	boolean checkPassword(String pwd);
	String currentUser();
	boolean transferAmt(int toAccNo, double money);
	
}
